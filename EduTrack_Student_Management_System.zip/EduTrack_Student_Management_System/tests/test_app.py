import tempfile
import unittest
from pathlib import Path

from main import (
    Student, StudentRecordService, calculate_grade, linear_search,
    binary_search_by_id, class_statistics, ValidationError
)


class GradeTests(unittest.TestCase):
    def test_grade_boundaries(self):
        self.assertEqual(calculate_grade(90), "A+")
        self.assertEqual(calculate_grade(80), "A")
        self.assertEqual(calculate_grade(70), "B")
        self.assertEqual(calculate_grade(60), "C")
        self.assertEqual(calculate_grade(40), "D")
        self.assertEqual(calculate_grade(39.99), "F")

    def test_pass_requires_each_subject(self):
        student = Student(1, "Test Student", "", "", "AI ML", 1, [100, 100, 100, 100, 34])
        self.assertEqual(student.result, "FAIL")
        self.assertEqual(student.total, 434)


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.students = [
            Student(3, "Charlie", "", "", "AI ML", 1, [80]*5),
            Student(1, "Alice", "", "", "AI ML", 1, [90]*5),
            Student(2, "Bob", "", "", "AI ML", 1, [70]*5),
        ]

    def test_linear_search(self):
        self.assertEqual(len(linear_search(self.students, "ali")), 1)
        self.assertEqual(linear_search(self.students, "unknown"), [])

    def test_binary_search(self):
        self.assertEqual(binary_search_by_id(self.students, 2).name, "Bob")
        self.assertIsNone(binary_search_by_id(self.students, 99))


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.service = StudentRecordService(Path(self.temp.name) / "test.db")

    def tearDown(self):
        self.temp.cleanup()

    def test_crud(self):
        student_id = self.service.add("Alice Test", "alice@example.com", "1234567890",
                                      "AI ML", 1, [80, 81, 82, 83, 84])
        self.assertEqual(self.service.get(student_id).name, "Alice Test")
        self.service.update(student_id, "Alice Updated", "", "", "AI ML", 2, [90]*5)
        self.assertEqual(self.service.get(student_id).semester, 2)
        self.service.delete(student_id)
        self.assertIsNone(self.service.get(student_id))

    def test_validation(self):
        with self.assertRaises(ValidationError):
            self.service.add("A", "", "", "AI ML", 1, [50]*5)
        with self.assertRaises(ValidationError):
            self.service.add("Alice Test", "", "", "AI ML", 1, [101]*5)

    def test_statistics_empty(self):
        stats = class_statistics([])
        self.assertEqual(stats["count"], 0)
        self.assertEqual(stats["average"], 0)


if __name__ == "__main__":
    unittest.main()
